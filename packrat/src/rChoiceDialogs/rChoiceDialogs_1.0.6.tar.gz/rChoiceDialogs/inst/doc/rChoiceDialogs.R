### R code from vignette source 'rChoiceDialogs.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: sessionInfo
###################################################

library(rChoiceDialogs)

toLatex(sessionInfo())



