#' rChoiceDialogs.
#'
#' \tabular{ll}{
#' Package: \tab rChoiceDialogs\cr
#' Type: \tab Package\cr
#' Version: \tab 1.0.4 \cr
#' Date: \tab 2012-10-11 \cr
#' License: \tab GPL (>= 2)\cr
#' LazyLoad: \tab yes\cr
#' }
#'
#'
#' @name rChoiceDialogs-package
#' @aliases rChoiceDialogs
#' @docType package
#' @author  Alex Lisovich, Roger Day
#' @keywords package
{}
