
Example
======================
Counting: 1 2 3